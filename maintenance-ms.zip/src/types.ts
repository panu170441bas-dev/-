export interface RepairRecord {
  rowNumber: number;
  jobNo: string;
  reportedAt: string;
  reporterId: string;
  location: string;
  machineNo: string;
  machineModel: string;
  spec: string;
  details: string;
  photoUrl: string;
  status: string;
  technicianId: string;
  completedAt: string;
  notes: string;
}

export interface UserProfile {
  email: string;
  id: string;
  name: string;
  googleName: string;
  role: "ผู้แจ้งซ่อม" | "ช่างซ่อม" | "ผู้ดูแลระบบ";
  status?: string;
}

export interface SheetUser {
  id: string;
  name: string;
  role: string;
  status?: string;
}

export interface ModelSpec {
  model: string;
  spec: string;
}

export interface MaintenanceConfig {
  profile: UserProfile;
  modelsAndSpecs: ModelSpec[];
  statuses: string[];
  users: SheetUser[];
  tabs: {
    modelSpecTab: string;
    statusTab: string;
    userTab: string;
    jobTab: string;
  };
}
