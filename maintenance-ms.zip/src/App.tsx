import React, { useState, useEffect } from "react";
import { User } from "firebase/auth";
import {
  initAuth,
  googleSignIn,
  logout,
  getAccessToken,
} from "@/src/lib/firebase";
import { RepairRecord, MaintenanceConfig } from "@/src/types";
import Dashboard from "@/src/components/Dashboard";
import RepairRequests from "@/src/components/RepairRequests";
import TaskHistory from "@/src/components/TaskHistory";
import Technicians from "@/src/components/Technicians";
import Settings from "@/src/components/Settings";

import {
  Wrench,
  LayoutDashboard,
  ClipboardList,
  History,
  Users,
  Settings as SettingsIcon,
  LogOut,
  Loader2,
  Lock,
  User as UserIcon,
  Download,
  Smartphone,
  Monitor,
  X,
} from "lucide-react";

export default function App() {
  // PWA Installation State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showHowToInstall, setShowHowToInstall] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);

  useEffect(() => {
    setIsInIframe(window.self !== window.top);
  }, []);

  useEffect(() => {
    // Check if app is running in standalone mode (installed as PWA)
    const checkStandalone = () => {
      const isStandaloneMode = window.matchMedia("(display-mode: standalone)").matches || 
                               (window.navigator as any).standalone || 
                               document.referrer.includes("android-app://");
      setIsStandalone(!!isStandaloneMode);
    };

    checkStandalone();

    const handleBeforeInstallPrompt = (e: any) => {
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
      // Update UI to notify the user they can install the PWA
      setIsInstallable(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    // If app is already installed
    window.addEventListener("appinstalled", () => {
      setIsStandalone(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        console.log("User accepted the install prompt");
        setIsInstallable(false);
        setDeferredPrompt(null);
      }
    } else {
      // Show "how to install" manual instructions modal
      setShowHowToInstall(true);
    }
  };

  // Auth state
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Custom login state variables
  const [userIdInput, setUserIdInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isLoggingInCustom, setIsLoggingInCustom] = useState(false);

  // Custom User / Sheet Session State
  const [customUser, setCustomUser] = useState<{ id: string; name: string; role: string; status: string } | null>(() => {
    try {
      const saved = localStorage.getItem("reliant_custom_user");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const handleSetCustomUser = (user: any) => {
    setCustomUser(user);
    if (user) {
      localStorage.setItem("reliant_custom_user", JSON.stringify(user));
    } else {
      localStorage.removeItem("reliant_custom_user");
    }
  };

  // App data state
  const [config, setConfig] = useState<MaintenanceConfig | null>(null);
  const [records, setRecords] = useState<RepairRecord[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [selectedJobNo, setSelectedJobNo] = useState<string | null>(null);

  // Navigation State
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "requests" | "history" | "technicians" | "settings"
  >("dashboard");

  // Check auth on load
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, activeToken) => {
        setUser(currentUser);
        setToken(activeToken);
        setNeedsAuth(false);
        setIsAuthLoading(false);
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true);
        setIsAuthLoading(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch app data when token or customUser changes
  useEffect(() => {
    if (token && customUser) {
      fetchData();
    }
  }, [token, customUser]);

  const fetchData = async () => {
    if (!token) return;
    setIsLoadingData(true);
    try {
      const headers: HeadersInit = { Authorization: `Bearer ${token}` };
      if (customUser) {
        headers["X-User-Id"] = customUser.id;
      }

      // 1. Fetch Config & User Profile
      const configRes = await fetch("/api/maintenance/config", {
        headers,
      });
      if (!configRes.ok) throw new Error("Failed to load reference configurations");
      const configData = await configRes.json();
      setConfig(configData);

      // 2. Fetch Repair Records
      const recordsRes = await fetch("/api/maintenance/records", {
        headers,
      });
      if (!recordsRes.ok) throw new Error("Failed to load repair records");
      const recordsData = await recordsRes.json();
      setRecords(recordsData);
    } catch (err) {
      console.error("Error fetching application data:", err);
    } finally {
      setIsLoadingData(false);
    }
  };

  const handleLogin = async () => {
    setIsSigningIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setToken(result.accessToken);
        setUser(result.user);
        setNeedsAuth(false);
      }
    } catch (err) {
      console.error("Login failed:", err);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleCustomLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setIsLoggingInCustom(true);
    try {
      const res = await fetch("/api/maintenance/login", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userIdInput,
          password: passwordInput,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "เข้าสู่ระบบไม่สำเร็จ");
      }

      const data = await res.json();
      if (data.success && data.user) {
        handleSetCustomUser(data.user);
        // Clear inputs on success
        setUserIdInput("");
        setPasswordInput("");
      }
    } catch (err: any) {
      setLoginError(err.message || "เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsLoggingInCustom(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setToken(null);
      setUser(null);
      handleSetCustomUser(null);
      setConfig(null);
      setRecords([]);
      setNeedsAuth(true);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  // Callback to add record
  const handleAddRecord = async (data: any) => {
    if (!token) throw new Error("Unauthorized");
    const headers: HeadersInit = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
    if (customUser) {
      headers["X-User-Id"] = customUser.id;
    }

    const res = await fetch("/api/maintenance/records", {
      method: "POST",
      headers,
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(errText || "Failed to create record");
    }

    const result = await res.json();
    // Refresh records
    fetchData();
    return result;
  };

  // Callback to update record
  const handleUpdateRecord = async (jobNo: string, data: any) => {
    if (!token) throw new Error("Unauthorized");
    const headers: HeadersInit = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
    if (customUser) {
      headers["X-User-Id"] = customUser.id;
    }

    const res = await fetch(`/api/maintenance/records/${jobNo}`, {
      method: "PUT",
      headers,
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(errText || "Failed to update record");
    }

    const result = await res.json();
    // Refresh records
    fetchData();
    return result;
  };

  // Helper to trigger view details of a specific job from any page
  const handleSelectJob = (jobNo: string) => {
    setSelectedJobNo(jobNo);
    setActiveTab("requests");
  };

  // Filter technicians based on user reference table
  const techniciansList = config?.users
    .filter((u) => u.role === "ช่างซ่อม")
    .map((u) => ({ id: u.id, name: u.name })) || [];

  // Render loading screen during initial authentication handshake
  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
        <span className="text-sm font-sans text-gray-500 mt-4 font-semibold">
          กำลังยืนยันตัวตนเข้าระบบ...
        </span>
      </div>
    );
  }

  // Render official Google Sign-In layout if not authenticated
  if (needsAuth || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-slate-800 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 sm:p-12 max-w-md w-full text-center space-y-6 border border-gray-100">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-sm">
            <Wrench className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900 font-display">
              Reliant Maintenance
            </h1>
            <p className="text-xs text-gray-400 font-sans mt-1.5 font-medium uppercase tracking-widest">
              Repair Management System
            </p>
            <p className="text-xs text-gray-500 font-sans mt-3 px-2">
              ระบบแจ้งซ่อมและประมวลผลงานของช่างเทคนิคโรงงาน ซิงค์ข้อมูลผ่าน Google Sheets & Google Drive
            </p>
          </div>

          <div className="pt-4 border-t border-gray-100 space-y-4">
            <button
              onClick={handleLogin}
              disabled={isSigningIn}
              className="gsi-material-button w-full flex items-center justify-center gap-3 border border-gray-300 rounded-xl py-3 px-4 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans shadow-sm disabled:opacity-50"
            >
              {isSigningIn ? (
                <>
                  <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                  กำลังลงชื่อเข้าใช้งาน...
                </>
              ) : (
                <>
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    className="w-5 h-5 flex-shrink-0"
                    style={{ display: "block" }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    ></path>
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    ></path>
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    ></path>
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    ></path>
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>

            {!isStandalone && (
              <button
                type="button"
                onClick={handleInstallApp}
                className="w-full flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl py-2.5 px-4 text-xs font-bold transition-all font-sans border border-blue-100"
              >
                <Download className="w-4 h-4" />
                <span>ติดตั้งแอปพลิเคชัน</span>
              </button>
            )}
          </div>

          <div className="text-[10px] text-gray-400 font-sans flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" /> Secure Google Workspace integration
          </div>
        </div>
      </div>
    );
  }

  // Render Custom Username & Password login form if authenticated via Google but not in Custom Session
  if (!customUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-zinc-950 flex flex-col items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 sm:p-12 max-w-md w-full space-y-6 border border-gray-100">
          <div className="text-center">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-sm mb-4">
              <Lock className="w-8 h-8" />
            </div>
            <h1 className="text-2xl font-extrabold text-gray-900 font-display">
              ลงชื่อเข้าใช้งาน
            </h1>
            <p className="text-xs text-slate-400 font-sans mt-1.5 font-medium uppercase tracking-wider">
              RELIANT MAINTENANCE SYSTEM
            </p>
          </div>

          <form onSubmit={handleCustomLogin} className="space-y-4 font-sans text-sm">
            {loginError && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl text-xs font-semibold leading-relaxed">
                ⚠️ {loginError}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wide">
                ID ผู้ใช้งาน
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="กรอก ID ผู้ใช้งาน (เช่น emp001)"
                  value={userIdInput}
                  onChange={(e) => setUserIdInput(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-xs"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wide">
                รหัสผ่าน
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type="password"
                  required
                  placeholder="กรอกรหัสผ่าน"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoggingInCustom}
              className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-blue-600 text-white rounded-xl py-2.5 px-4 font-bold transition-all shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 text-xs"
            >
              {isLoggingInCustom ? (
                <>
                  <Loader2 className="w-4 h-4 text-white animate-spin" />
                  กำลังตรวจสอบข้อมูลบัญชี...
                </>
              ) : (
                <span>เข้าสู่ระบบ</span>
              )}
            </button>
          </form>

          <div className="pt-4 border-t border-slate-100 flex flex-col items-center gap-2">
            <span className="text-[10px] text-slate-400 font-sans text-center">
              บัญชีเชื่อมต่อ Google: <strong className="text-slate-600">{user?.email}</strong>
            </span>
            <button
              onClick={async () => {
                let confirmed = true;
                try {
                  confirmed = window.confirm("คุณต้องการออกจากระบบ Google หรือไม่?");
                } catch (e) {
                  confirmed = true;
                }
                if (confirmed) {
                  await logout();
                  setToken(null);
                  setUser(null);
                  handleSetCustomUser(null);
                  setConfig(null);
                  setRecords([]);
                  setNeedsAuth(true);
                }
              }}
              type="button"
              className="text-[10px] font-bold text-rose-500 hover:underline"
            >
              เปลี่ยนบัญชี Google / ออกจากระบบ Google
            </button>

            {!isStandalone && (
              <button
                type="button"
                onClick={handleInstallApp}
                className="w-full flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl py-2 px-4 text-xs font-bold transition-all font-sans border border-blue-100 mt-2"
              >
                <Download className="w-4 h-4" />
                <span>ติดตั้งแอปพลิเคชัน</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Render general loading screen during Sheets sync
  if (!config) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
        <span className="text-sm font-sans text-gray-500 mt-4 font-semibold">
          กำลังดึงข้อมูลอ้างอิงและประสานงานผ่าน Google Sheets...
        </span>
      </div>
    );
  }

  // Render Main Layout once fully authenticated and synchronized
  return (
    <div className="min-h-screen bg-[#F1F5F9] flex flex-col lg:flex-row text-slate-900">
      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-72 bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col justify-between p-6 flex-shrink-0 text-white">
        <div className="space-y-8">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center shadow-md shadow-blue-500/10">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-md font-extrabold text-white tracking-tight leading-none font-display">
                RELIANT MS
              </h1>
              <span className="text-[10px] text-blue-400 font-sans font-bold tracking-widest uppercase mt-1 block">
                Maintenance
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1.5 font-sans">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === "dashboard"
                  ? "bg-slate-800 text-blue-400"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              แดชบอร์ดสรุปงาน
            </button>
            <button
              onClick={() => setActiveTab("requests")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === "requests"
                  ? "bg-slate-800 text-blue-400"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              การจัดการใบงานซ่อม
            </button>
            <button
              onClick={() => setActiveTab("history")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === "history"
                  ? "bg-slate-800 text-blue-400"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <History className="w-4 h-4" />
              ประวัติและคลังงานซ่อม
            </button>
            <button
              onClick={() => setActiveTab("technicians")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === "technicians"
                  ? "bg-slate-800 text-blue-400"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <Users className="w-4 h-4" />
              รายชื่อและข้อมูลทีมช่าง
            </button>
            {config.profile.role === "ผู้ดูแลระบบ" && (
              <button
                onClick={() => setActiveTab("settings")}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  activeTab === "settings"
                    ? "bg-slate-800 text-blue-400"
                    : "text-slate-400 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <SettingsIcon className="w-4 h-4" />
                ตั้งค่าข้อมูลอ้างอิง
              </button>
            )}
          </nav>
        </div>

        {/* User profile & Logout */}
        <div className="pt-6 border-t border-slate-800 mt-8 space-y-4 font-sans">
          <div className="bg-slate-800 rounded-2xl p-4 border border-slate-800/80">
            <div className="flex items-center gap-3">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt="user avatar"
                  className="w-10 h-10 rounded-full border border-slate-700"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center">
                  <UserIcon className="w-5 h-5" />
                </div>
              )}
              <div className="min-w-0">
                <p className="font-bold text-xs text-white truncate">
                  {config.profile.name}
                </p>
                <span className={`inline-block px-1.5 py-0.5 rounded text-[8px] font-extrabold mt-1 uppercase ${
                  config.profile.role === "ผู้ดูแลระบบ"
                    ? "bg-blue-950 text-blue-400 border border-blue-900"
                    : config.profile.role === "ช่างซ่อม"
                    ? "bg-emerald-950 text-emerald-400 border border-emerald-900"
                    : "bg-slate-700 text-slate-300"
                }`}>
                  {config.profile.role}
                </span>
              </div>
            </div>
          </div>

          {!isStandalone && (
            <div className="bg-slate-800/40 rounded-2xl p-3 border border-slate-800/60 space-y-2 mt-2">
              <div className="flex items-center gap-2 text-blue-400">
                <Download className="w-3.5 h-3.5" />
                <span className="text-[11px] font-bold">ติดตั้งแอปเพื่อใช้งานเต็มจอ</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                ติดตั้งแอปลงบนเครื่องเพื่อเปิดใช้งานแบบเต็มหน้าจอและโหลดรวดเร็วยิ่งขึ้น
              </p>
              <button
                type="button"
                onClick={handleInstallApp}
                className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold rounded-lg transition-colors"
              >
                กดเพื่อติดตั้งทันที
              </button>
            </div>
          )}

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-950/30 transition-all text-left"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            ออกจากระบบ
          </button>
        </div>
      </aside>

      {/* Main Content Viewport */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto max-h-screen">
        {isLoadingData && (
          <div className="fixed top-4 right-4 bg-white shadow-md border px-4 py-2 rounded-xl flex items-center gap-2 z-50 text-xs font-semibold font-sans text-gray-600">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
            กำลังประสานงานข้อมูล...
          </div>
        )}

        {/* Tab Router */}
        {activeTab === "dashboard" && (
          <Dashboard
            records={records}
            onSelectJob={handleSelectJob}
            userRole={config.profile.role}
          />
        )}
        {activeTab === "requests" && (
          <RepairRequests
            records={records}
            modelsAndSpecs={config.modelsAndSpecs}
            statuses={config.statuses}
            userProfile={config.profile}
            techniciansList={techniciansList}
            onAddRecord={handleAddRecord}
            onUpdateRecord={handleUpdateRecord}
            selectedJobNo={selectedJobNo}
            setSelectedJobNo={setSelectedJobNo}
            token={token}
          />
        )}
        {activeTab === "history" && (
          <TaskHistory
            records={records}
            userProfile={config.profile}
            statuses={config.statuses}
            onSelectJob={handleSelectJob}
            token={token}
          />
        )}
        {activeTab === "technicians" && (
          <Technicians records={records} users={config.users} />
        )}
        {activeTab === "settings" && (
          <Settings config={config} onRefresh={fetchData} isRefreshing={isLoadingData} userRole={config.profile.role} />
        )}
      </main>

      {/* How To Install Modal */}
      {showHowToInstall && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 font-sans">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl p-6 relative overflow-hidden border border-slate-100">
            <button
              onClick={() => setShowHowToInstall(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                <Download className="w-6 h-6" />
              </div>
              
              <div>
                <h3 className="text-lg font-extrabold text-slate-900">
                  วิธีการติดตั้งแอปพลิเคชัน
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  กรุณาติดตั้งแอปลงบนหน้าจอหลักเพื่อความสะดวกและใช้งานได้ราบรื่นยิ่งขึ้น
                </p>
              </div>

              {isInIframe && (
                <div className="p-3.5 bg-amber-50/90 border border-amber-200 rounded-2xl text-amber-950 space-y-2 mt-2">
                  <div className="flex items-center gap-2 font-black text-xs text-amber-900">
                    <span className="text-base">⚠️</span>
                    <span>ระบบพรีวิวในแชทบล็อกการติดตั้งแบบด่วน</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-amber-800">
                    เนื่องจากเปิดใช้งานภายในหน้าจอพรีวิวของช่องแชท ระบบความปลอดภัยของเบราว์เซอร์จะไม่ให้เรียกใช้หน้าต่างติดตั้งแอปโดยตรง
                  </p>
                  <p className="text-[11px] font-bold text-amber-950">
                    กรุณากดปุ่มด้านล่างเพื่อเปิดเว็บในแท็บใหม่แยกต่างหาก จากนั้นจึงกดติดตั้งหรือเพิ่มลงหน้าจอหลักได้ทันที:
                  </p>
                  <a
                    href="https://ais-pre-nxidptawcmxu3zfxwmrbbk-554615229221.asia-southeast1.run.app"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 active:scale-[0.98] text-white font-extrabold text-[11px] py-2 px-3 rounded-xl transition-all shadow-md shadow-amber-500/20"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>เปิดแอปในแท็บใหม่เพื่อติดตั้ง</span>
                  </a>
                </div>
              )}

              <div className="space-y-3.5 pt-2">
                {/* Android Chrome */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">สำหรับมือถือ Android (Chrome)</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      1. กดที่จุด 3 จุด <strong className="text-slate-700">⋮</strong> มุมขวาบนของเบราว์เซอร์ Chrome<br />
                      2. เลือกเมนู <strong className="text-slate-700">"ติดตั้งและสร้างทางลัด"</strong> หรือ <strong className="text-slate-700">"เพิ่มลงในหน้าจอหลัก"</strong><br />
                      3. กดยืนยันเพื่อติดตั้ง
                    </p>
                  </div>
                </div>

                {/* iPhone/iPad Safari */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">สำหรับ iPhone / iPad (Safari)</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      1. เปิดเว็บด้วยเบราว์เซอร์ <strong className="text-slate-700">Safari</strong> เท่านั้น<br />
                      2. กดปุ่ม <strong className="text-slate-700">"แชร์"</strong> (ปุ่มสี่เหลี่ยมที่มีลูกศรชี้ขึ้น ด้านล่างจอ)<br />
                      3. เลื่อนลงมาแล้วกดเลือก <strong className="text-slate-700">"เพิ่มไปยังหน้าจอโฮม" (Add to Home Screen)</strong>
                    </p>
                  </div>
                </div>

                {/* PC Chrome */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Monitor className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">สำหรับคอมพิวเตอร์ (Chrome / Edge)</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      1. มองหาไอคอนหน้าจอคอมพิวเตอร์บวก <strong className="text-slate-700">🖥️➕</strong> ที่อยู่ขวาสุดของช่องใส่ลิงก์เบราว์เซอร์<br />
                      2. หรือกดปุ่ม 3 จุด ➔ เลือก <strong className="text-slate-700">"ติดตั้ง..." (Install...)</strong>
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowHowToInstall(false)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors mt-2"
              >
                รับทราบและเข้าใจแล้ว
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
