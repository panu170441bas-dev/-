import React, { useState, useMemo, useRef } from "react";
import { RepairRecord, ModelSpec, UserProfile } from "@/src/types";
import {
  Camera,
  Upload,
  AlertCircle,
  CheckCircle,
  FileText,
  User,
  Plus,
  Loader2,
  X,
  MapPin,
  Cpu,
  Bookmark,
  Calendar,
  Layers,
} from "lucide-react";

interface RepairRequestsProps {
  records: RepairRecord[];
  modelsAndSpecs: ModelSpec[];
  statuses: string[];
  userProfile: UserProfile;
  techniciansList: { id: string; name: string }[];
  onAddRecord: (data: any) => Promise<any>;
  onUpdateRecord: (jobNo: string, data: any) => Promise<any>;
  selectedJobNo: string | null;
  setSelectedJobNo: (jobNo: string | null) => void;
  token: string;
}

export default function RepairRequests({
  records,
  modelsAndSpecs,
  statuses,
  userProfile,
  techniciansList,
  onAddRecord,
  onUpdateRecord,
  selectedJobNo,
  setSelectedJobNo,
  token,
}: RepairRequestsProps) {
  // Navigation tabs inside requests page: "ส่งงานแจ้งซ่อม" (Submit Job) or "รายการกำลังดำเนินการ" (Active List)
  const [activeSubTab, setActiveSubTab] = useState<"submit" | "active">("active");

  const currentSubTab = useMemo(() => {
    if (userProfile.role === "ผู้แจ้งซ่อม") {
      return "submit";
    }
    if (userProfile.role === "ช่างซ่อม") {
      return "active";
    }
    return activeSubTab;
  }, [activeSubTab, userProfile.role]);

  // Form State
  const [location, setLocation] = useState("");
  const [machineNo, setMachineNo] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [selectedSpec, setSelectedSpec] = useState("");
  const [details, setDetails] = useState("");
  const [compressedImage, setCompressedImage] = useState<string | null>(null);
  const [imageName, setImageName] = useState("");

  // UI States
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modal State for detail viewing / status updates
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<RepairRecord | null>(null);
  const [newStatus, setNewStatus] = useState("");
  const [technicianId, setTechnicianId] = useState("");
  const [notes, setNotes] = useState("");
  const [completedDate, setCompletedDate] = useState("");
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [modalSuccess, setModalSuccess] = useState("");
  const [modalError, setModalError] = useState("");

  // Filter specs based on selected model
  const filteredSpecs = useMemo(() => {
    if (!selectedModel) return [];
    return modelsAndSpecs.filter((item) => item.model === selectedModel);
  }, [selectedModel, modelsAndSpecs]);

  // Extract unique models
  const uniqueModels = useMemo(() => {
    const set = new Set<string>();
    modelsAndSpecs.forEach((item) => {
      if (item.model) set.add(item.model);
    });
    return Array.from(set);
  }, [modelsAndSpecs]);

  // Active records (not Completed or Cancelled)
  const activeRecords = useMemo(() => {
    return records.filter((r) => r.status !== "เสร็จสิ้น" && r.status !== "ยกเลิก");
  }, [records]);

  // Handle image compression (fixing iPhone files size & orientation)
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    setErrorMessage("");

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Create Canvas for compression
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        // Scale down to max 1024px width or height
        const MAX_SIZE = 1024;
        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          // Compress to JPEG with 0.7 quality (perfectly balances weight and quality)
          const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
          setCompressedImage(dataUrl);
          setImageName(file.name);
        }
        setIsUploadingImage(false);
      };
      img.onerror = () => {
        setErrorMessage("ไม่สามารถโหลดรูปภาพได้ กรุณาลองใหม่อีกครั้ง");
        setIsUploadingImage(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Drag and Drop triggers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      if (fileInputRef.current) {
        // Create a Mock FileList or trigger reader directly
        const dt = new DataTransfer();
        dt.items.add(file);
        fileInputRef.current.files = dt.files;
        const event = { target: fileInputRef.current } as React.ChangeEvent<HTMLInputElement>;
        handleImageChange(event);
      }
    }
  };

  // Submit new request
  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    // Validation
    if (!machineNo.trim()) return setErrorMessage("กรุณาระบุเลขเครื่อง");
    
    // Strict requirement validation: "เลขเครื่อง (พิมพ์ข้อความ ❌ ห้ามเป็นตัวเลข ป้องกันเลข 0 หาย)"
    // If the input is completely digits (numbers only), show an explicit warning error
    if (/^\d+$/.test(machineNo.trim())) {
      return setErrorMessage("เลขเครื่องห้ามป้อนเป็นตัวเลขล้วน ❌ กรุณาใส่ตัวอักษรหรือสัญลักษณ์ร่วมด้วย (เช่น เครื่อง1, เครื่อง2 หรือ เครื่อง1-5)");
    }

    if (!selectedModel) return setErrorMessage("กรุณาเลือกรุ่นเครื่องจักร");
    if (!selectedSpec) return setErrorMessage("กรุณาเลือกประเภทปัญหา");
    if (!details.trim()) return setErrorMessage("กรุณากรอกรายละเอียดปัญหา");

    setIsSubmitting(true);

    try {
      let finalPhotoUrl = "";

      // 1. If we have a compressed image, upload it to Google Drive folder
      if (compressedImage) {
        const uploadRes = await fetch("/api/maintenance/upload", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            base64Data: compressedImage,
            fileName: `repair_${machineNo}_${Date.now()}.jpg`,
          }),
        });

        if (!uploadRes.ok) {
          throw new Error("ไม่สามารถอัปโหลดรูปภาพไปยัง Google Drive ได้");
        }

        const uploadData = await uploadRes.json();
        finalPhotoUrl = uploadData.photoUrl;
      }

      // 2. Add record to Google Sheet
      const result = await onAddRecord({
        location: "-", // Pass default placeholder for location
        machineNo,
        machineModel: selectedModel,
        spec: selectedSpec,
        details,
        photoUrl: finalPhotoUrl,
      });

      setSuccessMessage(`ส่งใบแจ้งซ่อมสำเร็จ! เลขที่งานของคุณคือ: ${result.jobNo}`);
      
      // Reset Form
      setLocation("");
      setMachineNo("");
      setSelectedModel("");
      setSelectedSpec("");
      setDetails("");
      setCompressedImage(null);
      setImageName("");
      setActiveSubTab("active"); // Direct user to active list
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "เกิดข้อผิดพลาดในการส่งข้อมูล");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open modal and prepopulate values
  const handleOpenEditModal = (job: RepairRecord) => {
    // Permission check
    if (userProfile.role === "ผู้แจ้งซ่อม") {
      // Reporters can view, but not change status. We show the details anyway but hide the state mutator
    }
    setEditingJob(job);
    setNewStatus(job.status);
    setTechnicianId(job.technicianId || "");
    setNotes(job.notes || "");
    setCompletedDate(
      job.completedAt || new Date().toLocaleDateString("th-TH")
    );
    setModalSuccess("");
    setModalError("");
    setIsEditModalOpen(true);
  };

  // Update record operational details
  const handleUpdateStatus = async () => {
    if (!editingJob) return;

    setModalSuccess("");
    setModalError("");
    setIsUpdatingStatus(true);
    try {
      await onUpdateRecord(editingJob.jobNo, {
        status: newStatus,
        technicianId,
        notes,
        completedAt: newStatus === "เสร็จสิ้น" ? completedDate : "",
      });

      setModalSuccess("บันทึกการปรับปรุงสถานะและข้อมูลปฏิบัติงานสำเร็จเรียบร้อยแล้ว!");
      
      // Auto-close modal after 1.5 seconds to allow user to see the success message
      setTimeout(() => {
        setIsEditModalOpen(false);
        setEditingJob(null);
        setModalSuccess("");
      }, 1500);
    } catch (err: any) {
      console.error(err);
      setModalError("เกิดข้อผิดพลาดในการบันทึกข้อมูล: " + (err.message || ""));
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  // Match job if redirected from Dashboard
  React.useEffect(() => {
    if (selectedJobNo) {
      const job = records.find((r) => r.jobNo === selectedJobNo);
      if (job) {
        handleOpenEditModal(job);
      }
      setSelectedJobNo(null);
    }
  }, [selectedJobNo, records]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Mode Selector */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <span className="w-1.5 h-5 bg-blue-500 rounded-full inline-block"></span>
            {currentSubTab === "active" ? "รายการที่กำลังดำเนินงาน" : "แบบฟอร์มแจ้งซ่อมใหม่"}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 font-sans">
            {currentSubTab === "active"
              ? `มีเครื่องจักรที่กำลังรอซ่อมหรือตรวจงานอยู่ ${activeRecords.length} รายการ`
              : "กรอกข้อมูลรายละเอียดของปัญหาเพื่อส่งเข้าสู่ระบบจัดการซ่อมบำรุง"}
          </p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          {userProfile.role !== "ผู้แจ้งซ่อม" && (
            <button
              onClick={() => {
                setActiveSubTab("active");
                setErrorMessage("");
                setSuccessMessage("");
              }}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                currentSubTab === "active"
                  ? "bg-slate-900 text-white shadow-sm shadow-slate-900/10"
                  : "bg-slate-50 text-slate-600 hover:bg-slate-100"
              }`}
            >
              รายการดำเนินงาน ({activeRecords.length})
            </button>
          )}
          {userProfile.role !== "ช่างซ่อม" && (
            <button
              onClick={() => {
                setActiveSubTab("submit");
                setErrorMessage("");
                setSuccessMessage("");
              }}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                currentSubTab === "submit"
                  ? "bg-slate-900 text-white shadow-sm shadow-slate-900/10"
                  : "bg-slate-50 text-slate-600 hover:bg-slate-100"
              }`}
            >
              <Plus className="w-4 h-4" />
              แจ้งซ่อมเครื่องจักร
            </button>
          )}
        </div>
      </div>

      {successMessage && (
        <div className="bg-emerald-50/80 border border-emerald-100 p-4 rounded-2xl flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-emerald-800">สำเร็จ!</h4>
            <p className="text-xs text-emerald-700 mt-1 font-sans">{successMessage}</p>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-50/80 border border-rose-100 p-4 rounded-2xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-rose-800">พบข้อผิดพลาด</h4>
            <p className="text-xs text-rose-700 mt-1 font-sans">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Subtab: Submit Job Form */}
      {currentSubTab === "submit" && (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden max-w-4xl mx-auto">
          <div className="p-6 sm:p-8">
            <form onSubmit={handleSubmitRequest} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                {/* Machine No (Text format required strictly) */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                    เลขเครื่อง (ห้ามเป็นตัวเลขล้วน ❌)
                  </label>
                  <div className="relative">
                    <Cpu className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="เช่น เครื่อง1, เครื่อง2 หรือ เครื่อง1-5"
                      value={machineNo}
                      onChange={(e) => setMachineNo(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800"
                      required
                    />
                  </div>
                  <span className="text-[10px] text-rose-500 font-bold font-sans block leading-relaxed mt-1">
                    * ห้ามพิมพ์ตัวเลขล้วน เพื่อป้องกันระบบตัดเลข 0 ข้างหน้าหาย (เช่น เครื่อง1, เครื่อง2 หรือ เครื่อง1-5)
                  </span>
                </div>

                {/* Machine Model Selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                    รุ่นเครื่องจักร
                  </label>
                  <div className="relative">
                    <Bookmark className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <select
                      value={selectedModel}
                      onChange={(e) => {
                        setSelectedModel(e.target.value);
                        setSelectedSpec(""); // Reset spec on model change
                      }}
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 appearance-none"
                      required
                    >
                      <option value="">-- เลือกรุ่นเครื่องจักร --</option>
                      {uniqueModels.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Job Spec / Problem Category (Cascades from model selection) */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                    สเปคงาน / ประเภทปัญหา
                  </label>
                  <div className="relative">
                    <Layers className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <select
                      value={selectedSpec}
                      onChange={(e) => setSelectedSpec(e.target.value)}
                      disabled={!selectedModel}
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 appearance-none disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                      required
                    >
                      <option value="">
                        {!selectedModel ? "-- กรุณาเลือกรุ่นก่อน --" : "-- เลือกประเภทปัญหาของรุ่นนี้ --"}
                      </option>
                      {filteredSpecs.map((item, idx) => (
                        <option key={idx} value={item.spec}>
                          {item.spec}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Problem Details */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                    รายละเอียดปัญหา
                  </label>
                  <textarea
                    placeholder="กรุณาอธิบายอาการเสีย เสียงดังผิดปกติ หรือรหัสแจ้งเตือนที่แสดงบนหน้าจอ..."
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    rows={4}
                    className="w-full p-4 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 resize-none"
                    required
                  />
                </div>

                {/* Auto Compress Camera & Album Upload (iPhone Safe) */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                    รูปถ่ายประกอบอาการเสีย
                  </label>
                  <div
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100/50 hover:border-blue-500 transition-colors cursor-pointer group"
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleImageChange}
                      accept="image/*"
                      className="hidden"
                    />
                    
                    {isUploadingImage ? (
                      <div className="flex flex-col items-center py-4">
                        <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                        <span className="text-xs text-slate-500 mt-2 font-sans font-medium">กำลังบีบอัดรูปถ่ายอัตโนมัติ...</span>
                      </div>
                    ) : compressedImage ? (
                      <div className="relative w-full max-w-xs flex flex-col items-center text-center">
                        <img
                          src={compressedImage}
                          alt="compressed repair"
                          className="w-40 h-40 object-cover rounded-xl border border-slate-200 shadow-sm"
                        />
                        <span className="text-xs text-slate-600 mt-2 font-sans font-semibold truncate max-w-full">
                          {imageName}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setCompressedImage(null);
                            setImageName("");
                          }}
                          className="absolute -top-2 -right-2 bg-rose-100 text-rose-600 p-1.5 rounded-full hover:bg-rose-200 shadow border border-rose-200"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <Camera className="w-5 h-5" />
                        </div>
                        <span className="font-bold text-sm text-slate-700">คลิกเพื่อถ่ายรูป หรือ เลือกจากคลังภาพ</span>
                        <span className="text-xs text-slate-400 mt-1 font-sans text-center">
                          รองรับการลากไฟล์รูปภาพมาวางที่นี่ (บีบอัดไฟล์ภาพ iPhone อัตโนมัติ แก้ไขปัญหาภาพใหญ่โหลดช้า)
                        </span>
                      </>
                    )}
                  </div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-6 border-t border-slate-100 flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => {
                    if (userProfile.role !== "ผู้แจ้งซ่อม") {
                      setActiveSubTab("active");
                    }
                    setLocation("");
                    setMachineNo("");
                    setSelectedModel("");
                    setSelectedSpec("");
                    setDetails("");
                    setCompressedImage(null);
                    setImageName("");
                  }}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-50 transition-colors"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || isUploadingImage}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-blue-500 text-white shadow-md shadow-blue-500/10 hover:bg-blue-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-all flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      กำลังบันทึกงาน...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      ส่งข้อมูลใบแจ้งซ่อม
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Subtab: Active Job List */}
      {currentSubTab === "active" && (
        <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100">
            <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-amber-500 rounded-full inline-block"></span>
              รายการเครื่องจักรขัดข้องที่กำลังอยู่ระหว่างการจัดการ
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100">
                  <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                    เลขที่งาน / วันเวลาที่แจ้ง
                  </th>
                  <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                    รุ่นเครื่องจักร / อาการเสีย
                  </th>
                  <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                    สถานะการซ่อม
                  </th>
                  <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500 text-center">
                    การจัดการ
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeRecords.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-12 text-center text-slate-400 font-sans">
                      <CheckCircle className="w-12 h-12 text-emerald-500 bg-emerald-50 p-2.5 rounded-full mx-auto mb-3" />
                      ไม่มีงานค้างอยู่ในระบบ การทำงานทุกไลน์การผลิตราบรื่นปกติ!
                    </td>
                  </tr>
                ) : (
                  activeRecords.map((record) => (
                    <tr
                      key={record.jobNo}
                      className="hover:bg-slate-50/30 transition-colors"
                    >
                      <td className="py-4 px-6 font-sans">
                        <span className="font-bold text-blue-600">{record.jobNo}</span>
                        <div className="text-[10px] text-slate-400 font-sans mt-0.5">{record.reportedAt}</div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="font-bold text-slate-800 text-sm">
                          {record.machineModel} ({record.machineNo})
                        </div>
                        <div className="text-xs text-slate-500 font-sans truncate max-w-sm mt-0.5">
                          {record.spec} - {record.details}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span
                          className={`inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-bold font-sans ${
                            record.status === "รับแจ้งแล้ว"
                              ? "bg-amber-100 text-amber-800 border border-amber-200"
                              : record.status === "กำลังดำเนินการ"
                              ? "bg-blue-100 text-blue-800 border border-blue-200"
                              : "bg-amber-100 text-amber-800 border border-amber-200"
                          }`}
                        >
                          {record.status}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <button
                          onClick={() => handleOpenEditModal(record)}
                          className="bg-blue-50 text-blue-600 hover:bg-blue-100 hover:text-blue-700 px-4 py-1.5 rounded-xl text-xs font-bold transition-colors border border-blue-100"
                        >
                          {userProfile.role === "ผู้แจ้งซ่อม" ? "ดูรายละเอียด" : "อัปเดตงาน"}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modern Status Update & View Details Modal */}
      {isEditModalOpen && editingJob && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-8 border border-slate-100">
            {/* Modal Header */}
            <div className="bg-slate-50 px-6 py-5 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-slate-800 font-display flex items-center gap-2">
                  <span className="w-1.5 h-4 bg-blue-500 rounded-full inline-block"></span>
                  รายละเอียดของงาน {editingJob.jobNo}
                </h3>
                <p className="text-xs text-slate-400 font-sans mt-0.5">
                  แจ้งซ่อมเมื่อ: {editingJob.reportedAt}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsEditModalOpen(false);
                  setEditingJob(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
              {modalSuccess && (
                <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-start gap-2.5 text-xs font-semibold">
                  <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5 animate-bounce" />
                  <span>{modalSuccess}</span>
                </div>
              )}

              {modalError && (
                <div className="p-4 bg-rose-50 border border-rose-100 text-rose-800 rounded-2xl flex items-start gap-2.5 text-xs font-semibold">
                  <X className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  <span>{modalError}</span>
                </div>
              )}

              {/* Problem Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div>
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">ผู้แจ้งซ่อม:</span>
                  <p className="font-semibold text-slate-800 font-sans mt-1">{editingJob.reporterId}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">รุ่นเครื่องจักร:</span>
                  <p className="font-bold text-slate-800 mt-1">{editingJob.machineModel}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">เลขเครื่อง (รหัสเครื่อง):</span>
                  <p className="font-bold text-slate-800 mt-1">{editingJob.machineNo}</p>
                </div>
                <div className="sm:col-span-2 border-t border-slate-200/60 pt-3">
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">ประเภทปัญหา/สเปคงาน:</span>
                  <p className="font-bold text-blue-600 text-sm mt-1">{editingJob.spec}</p>
                </div>
                <div className="sm:col-span-2">
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">รายละเอียดปัญหาเพิ่มเติม:</span>
                  <p className="text-slate-700 mt-1.5 font-sans bg-white p-3.5 rounded-xl border border-slate-200/60 whitespace-pre-wrap leading-relaxed text-xs">
                    {editingJob.details}
                  </p>
                </div>
              </div>

              {/* Repair Photo if exists */}
              {editingJob.photoUrl && (
                <div className="space-y-1.5">
                  <span className="text-slate-400 text-[10px] font-bold font-sans uppercase tracking-wider block">รูปภาพประกอบอาการเสียหาย:</span>
                  <div className="border border-slate-200/60 rounded-2xl overflow-hidden max-w-sm mt-1.5 shadow-sm bg-slate-50">
                    <img
                      src={`${editingJob.photoUrl}?token=${token}`}
                      alt="machine repair context"
                      className="w-full max-h-64 object-cover"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        e.currentTarget.src = "https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=300";
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Status Update Operations Block (Visible ONLY for Technicians & Admins) */}
              {userProfile.role !== "ผู้แจ้งซ่อม" ? (
                <div className="border-t border-slate-100 pt-6 space-y-4">
                  <h4 className="text-sm font-bold text-slate-800 border-l-4 border-blue-500 pl-2">
                    ส่วนของช่างเทคนิคผู้ปฏิบัติงานซ่อม
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Select Status */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                        ปรับปรุงสถานะงาน
                      </label>
                      <select
                        value={newStatus}
                        onChange={(e) => setNewStatus(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800"
                      >
                        {statuses.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Assigned Technician ID */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                        ผู้ปฏิบัติงาน / ช่างผู้รับผิดชอบ
                      </label>
                      <select
                        value={technicianId}
                        onChange={(e) => setTechnicianId(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800"
                      >
                        <option value="">-- ไม่ระบุ (ยังไม่ได้มอบหมาย) --</option>
                        {techniciansList.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Finished Date (Visible if status is 'เสร็จสิ้น') */}
                    {newStatus === "เสร็จสิ้น" && (
                      <div className="space-y-1.5 sm:col-span-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                          วันที่เสร็จสิ้น
                        </label>
                        <div className="relative">
                          <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            placeholder="เช่น 20/07/2569"
                            value={completedDate}
                            onChange={(e) => setCompletedDate(e.target.value)}
                            className="w-full pl-9 pr-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800"
                          />
                        </div>
                      </div>
                    )}

                    {/* Notes / Outcomes */}
                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-sans">
                        ผลการดำเนินงาน / หมายเหตุ
                      </label>
                      <textarea
                        placeholder="สรุปผลการซ่อมแซม, การเปลี่ยนอะไหล่ หรือหมายเหตุเพิ่มเติม..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        rows={3}
                        className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 resize-none"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                /* Static view of operations block for simple Reporters */
                <div className="border-t border-slate-100 pt-6 space-y-3 font-sans text-xs">
                  <h4 className="font-bold text-slate-800 border-l-4 border-blue-500 pl-2">ความคืบหน้าการปฏิบัติงานของช่าง</h4>
                  <div className="grid grid-cols-2 gap-4 bg-blue-50/40 p-4 rounded-2xl border border-blue-100/50">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">สถานะงานปัจจุบัน:</span>
                      <p className="font-bold text-blue-700 text-sm mt-1">{editingJob.status}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">ช่างรับผิดชอบ:</span>
                      <p className="font-semibold text-slate-800 text-sm mt-1">
                        {editingJob.technicianId || "รอช่างมารับงาน"}
                      </p>
                    </div>
                    {editingJob.completedAt && (
                      <div className="col-span-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">วันที่เสร็จงาน:</span>
                        <p className="font-semibold text-slate-800 text-sm mt-1">{editingJob.completedAt}</p>
                      </div>
                    )}
                    {editingJob.notes && (
                      <div className="col-span-2 border-t border-slate-200/50 pt-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">ผลการดำเนินงาน/หมายเหตุ:</span>
                        <p className="text-slate-700 text-xs mt-1.5 bg-white p-3 rounded-xl border border-slate-100 leading-relaxed">
                          {editingJob.notes}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setIsEditModalOpen(false);
                  setEditingJob(null);
                }}
                className="px-5 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 font-sans transition-all"
              >
                ปิดหน้าต่าง
              </button>
              {userProfile.role !== "ผู้แจ้งซ่อม" && (
                <button
                  type="button"
                  onClick={handleUpdateStatus}
                  disabled={isUpdatingStatus}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-500 text-white shadow shadow-blue-500/10 hover:bg-blue-600 disabled:bg-slate-300 font-sans transition-all flex items-center gap-1.5"
                >
                  {isUpdatingStatus && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  บันทึกข้อมูลปฏิบัติงาน
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
