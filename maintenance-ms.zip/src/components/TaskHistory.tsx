import React, { useState, useMemo } from "react";
import { RepairRecord, UserProfile } from "@/src/types";
import {
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Eye,
  Calendar,
  Layers,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
} from "lucide-react";

interface TaskHistoryProps {
  records: RepairRecord[];
  userProfile: UserProfile;
  statuses: string[];
  onSelectJob: (jobNo: string) => void;
  token: string;
}

export default function TaskHistory({
  records,
  userProfile,
  statuses,
  onSelectJob,
  token,
}: TaskHistoryProps) {
  // Filters State
  const [search, setSearch] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Extract unique models present in history
  const uniqueModels = useMemo(() => {
    const set = new Set<string>();
    records.forEach((r) => {
      if (r.machineModel) set.add(r.machineModel);
    });
    return Array.from(set);
  }, [records]);

  // Filter records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        r.jobNo.toLowerCase().includes(search.toLowerCase()) ||
        r.details.toLowerCase().includes(search.toLowerCase()) ||
        r.machineNo.toLowerCase().includes(search.toLowerCase());

      const matchStatus = selectedStatus ? r.status === selectedStatus : true;
      const matchModel = selectedModel ? r.machineModel === selectedModel : true;

      return matchSearch && matchStatus && matchModel;
    });
  }, [records, search, selectedStatus, selectedModel]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage) || 1;
  const paginatedRecords = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredRecords.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredRecords, currentPage]);

  const stats = useMemo(() => {
    const completed = records.filter((r) => r.status === "เสร็จสิ้น").length;
    const cancelled = records.filter((r) => r.status === "ยกเลิก").length;
    const others = records.filter((r) => r.status !== "เสร็จสิ้น" && r.status !== "ยกเลิก").length;
    return { completed, cancelled, others };
  }, [records]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <span className="w-1.5 h-5 bg-blue-500 rounded-full inline-block"></span>
            ประวัติงานซ่อมแซมทั้งหมด
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 font-sans">
            ตรวจสอบประวัติงานแจ้งซ่อมที่ได้รับการแก้ไขเรียบร้อยแล้ว หรือยกเลิกไปแล้วในคลังข้อมูล Google Sheets
          </p>
        </div>
      </div>

      {/* KPI Summaries */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900 font-sans leading-none">{stats.completed}</div>
            <div className="text-xs text-slate-400 font-bold font-sans mt-1.5 uppercase tracking-wider">งานที่ซ่อมเสร็จสิ้น</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-rose-50 text-rose-600">
            <XCircle className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900 font-sans leading-none">{stats.cancelled}</div>
            <div className="text-xs text-slate-400 font-bold font-sans mt-1.5 uppercase tracking-wider">งานที่ถูกยกเลิก</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-blue-50 text-blue-600">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900 font-sans leading-none">{stats.others}</div>
            <div className="text-xs text-slate-400 font-bold font-sans mt-1.5 uppercase tracking-wider">งานที่กำลังซ่อมแซม</div>
          </div>
        </div>
      </div>

      {/* Filters and Table Card */}
      <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm overflow-hidden">
        {/* Filters Panel */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col lg:flex-row gap-4 items-center">
          {/* Search bar */}
          <div className="relative w-full lg:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ค้นหาตามรหัสงาน, อาการ, เลขเครื่อง..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 py-2 bg-white rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800"
            />
          </div>

          {/* Filter Status */}
          <div className="flex gap-4 w-full lg:w-auto flex-col sm:flex-row">
            <div className="relative flex-1 sm:w-48">
              <Filter className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                value={selectedStatus}
                onChange={(e) => {
                  setSelectedStatus(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full pl-9 pr-4 py-2 bg-white rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 appearance-none"
              >
                <option value="">-- กรองด้วยสถานะ --</option>
                {statuses.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter Model */}
            <div className="relative flex-1 sm:w-48">
              <Layers className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                value={selectedModel}
                onChange={(e) => {
                  setSelectedModel(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full pl-9 pr-4 py-2 bg-white rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs text-slate-800 appearance-none"
              >
                <option value="">-- กรองด้วยรุ่น --</option>
                {uniqueModels.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Historical Records Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  รหัสงาน
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  เครื่องจักร
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  รายละเอียด / สเปคปัญหา
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  ช่างผู้ปฏิบัติการ
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500 text-center">
                  สถานะ
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500 text-right">
                  การจัดการ
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 font-sans">
                    <HelpCircle className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                    ไม่พบข้อมูลงานซ่อมในประวัติที่ตรงกับเงื่อนไข
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((record) => (
                  <tr
                    key={record.jobNo}
                    className="hover:bg-slate-50/30 transition-colors"
                  >
                    <td className="py-4 px-6">
                      <span className="font-bold text-blue-600 font-sans">{record.jobNo}</span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-bold text-slate-800">{record.machineModel}</p>
                      <p className="text-xs text-slate-400 font-sans mt-0.5">
                        เลขเครื่อง: {record.machineNo}
                      </p>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-semibold text-slate-800 text-xs">{record.spec}</p>
                      <p className="text-xs text-slate-500 truncate max-w-xs font-sans mt-0.5">
                        {record.details}
                      </p>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-semibold text-slate-700 text-xs font-sans">
                        {record.technicianId || "ไม่ได้ระบุช่าง"}
                      </p>
                      {record.completedAt && (
                        <p className="text-[10px] text-emerald-600 font-sans mt-0.5">
                          เสร็จเมื่อ: {record.completedAt}
                        </p>
                      )}
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span
                        className={`inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-bold font-sans ${
                          record.status === "เสร็จสิ้น"
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                            : record.status === "ยกเลิก"
                            ? "bg-rose-100 text-rose-800 border border-rose-200"
                            : "bg-blue-100 text-blue-800 border border-blue-200"
                        }`}
                      >
                        {record.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={() => onSelectJob(record.jobNo)}
                        className="text-blue-600 hover:text-blue-800 p-1.5 hover:bg-blue-50 rounded-xl transition-all flex items-center justify-center gap-1 text-xs font-bold inline-flex border border-transparent hover:border-blue-100"
                      >
                        <Eye className="w-4 h-4" />
                        ดูรายละเอียด
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Panel */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100 bg-white">
            <span className="text-xs text-slate-400 font-sans">
              แสดง {(currentPage - 1) * itemsPerPage + 1} ถึง{" "}
              {Math.min(currentPage * itemsPerPage, filteredRecords.length)} จากทั้งหมด{" "}
              {filteredRecords.length} รายการ
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-50 disabled:hover:bg-transparent transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4 text-slate-600" />
              </button>
              
              <span className="text-xs font-bold text-slate-700 font-sans px-3">
                หน้า {currentPage} / {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-50 disabled:hover:bg-transparent transition-all cursor-pointer"
              >
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
