import React from "react";
import { MaintenanceConfig } from "@/src/types";
import {
  FileSpreadsheet,
  Settings as SettingsIcon,
  ShieldAlert,
  User,
  BookOpen,
  ListOrdered,
  Layers,
  ArrowUpRight,
  RefreshCw,
} from "lucide-react";

interface SettingsProps {
  config: MaintenanceConfig | null;
  onRefresh: () => void;
  isRefreshing: boolean;
  userRole?: string;
}

export default function Settings({ config, onRefresh, isRefreshing, userRole }: SettingsProps) {
  const SPREADSHEET_ID = "1zLZo2Igpqk59skiAyFTBPhgbq4J1Gm47zA4Y0ru6-Dg";
  const sheetUrl = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <SettingsIcon className="w-6 h-6 text-blue-500" />
            การตั้งค่าข้อมูลอ้างอิงระบบ
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            ข้อมูลอ้างอิงทั้งหมดในระบบ ซิงค์สดและแก้ไขได้โดยตรงบน Google Sheets
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="px-4 py-2 bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-100 transition-all flex items-center gap-1.5 self-stretch sm:self-auto justify-center disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-blue-500 ${isRefreshing ? "animate-spin" : ""}`} />
          รีเฟรชซิงค์ข้อมูลใหม่
        </button>
      </div>

      {/* Main Direct Google Sheet Link Card */}
      {userRole === "ผู้ดูแลระบบ" && (
        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex gap-4 items-start">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0 border border-emerald-100">
              <FileSpreadsheet className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200/60 font-bold px-2.5 py-0.5 rounded-full font-sans uppercase tracking-wider">
                Dynamic Synchronization
              </span>
              <h3 className="text-lg font-bold text-slate-800 mt-2">
                แก้ไขข้อมูลอ้างอิงระบบได้ที่หน้า Google Sheet ทันที
              </h3>
              <p className="text-xs text-slate-500 font-sans mt-1 max-w-xl">
                คุณสามารถ เพิ่ม, ลบ หรือแก้ไขข้อมูล รุ่นเครื่องจักร, สเปคงาน/อาการเสีย, รายชื่อพนักงาน, สิทธิ์การใช้งาน หรือแท็บสถานะได้ง่ายๆ เพียงอัปเดตในสเปรดชีต แล้วระบบจะทำงานตามนั้นทันทีโดยไม่ต้องแก้โค้ดโปรแกรมใดๆ
              </p>
            </div>
          </div>
          <a
            href={sheetUrl}
            target="_blank"
            referrerPolicy="no-referrer"
            className="w-full md:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer border border-emerald-700/50"
          >
            เปิดหน้า Google Sheet
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>
      )}

      {/* Synchronized Metadata Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Users & Roles List */}
        <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 space-y-4">
          <div className="flex gap-2.5 items-center border-b border-slate-100 pb-3">
            <div className="w-8 h-8 bg-blue-50 text-blue-600 border border-blue-100 rounded-lg flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">รายชื่อพนักงานในระบบ</h4>
              <span className="text-[10px] text-slate-400 font-sans font-medium">
                แท็บ: {config?.tabs?.userTab || "ผู้ใช้งาน"}
              </span>
            </div>
          </div>
          <div className="overflow-y-auto max-h-72 space-y-2 pr-1 scrollbar-thin">
            {!config || config.users.length === 0 ? (
              <span className="text-xs text-slate-400 font-sans block text-center py-4">ไม่มีผู้ใช้งานระบุในชีต</span>
            ) : (
              config.users.map((u) => (
                <div key={u.id} className="flex justify-between items-center bg-slate-50 border border-slate-100 p-2.5 rounded-2xl text-xs font-sans">
                  <div>
                    <p className="font-bold text-slate-800">{u.name}</p>
                    <p className="text-[10px] text-slate-400 truncate max-w-[150px]">รหัส: {u.id}</p>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    u.role === "ผู้ดูแลระบบ"
                      ? "bg-purple-100 text-purple-800 border border-purple-200"
                      : u.role === "ช่างซ่อม"
                      ? "bg-blue-100 text-blue-800 border border-blue-200"
                      : "bg-slate-100 text-slate-800 border border-slate-200"
                  }`}>
                    {u.role}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Models and Specs Merged Reference */}
        <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 space-y-4">
          <div className="flex gap-2.5 items-center border-b border-slate-100 pb-3">
            <div className="w-8 h-8 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-lg flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">รุ่นเครื่องจักรและสเปคปัญหา</h4>
              <span className="text-[10px] text-slate-400 font-sans font-medium">
                แท็บ: {config?.tabs?.modelSpecTab || "รุ่น+สเปค"}
              </span>
            </div>
          </div>
          <div className="overflow-y-auto max-h-72 space-y-2 pr-1 scrollbar-thin">
            {!config || config.modelsAndSpecs.length === 0 ? (
              <span className="text-xs text-slate-400 font-sans block text-center py-4">ไม่มีรุ่นและอาการระบุในชีต</span>
            ) : (
              config.modelsAndSpecs.map((ms, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-100 p-2.5 rounded-2xl text-xs">
                  <span className="text-[9px] bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded-full font-bold uppercase font-sans border border-indigo-200/60">
                    รุ่น {ms.model}
                  </span>
                  <p className="font-bold text-slate-800 mt-1">{ms.spec}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Statuses Options List */}
        <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 space-y-4">
          <div className="flex gap-2.5 items-center border-b border-slate-100 pb-3">
            <div className="w-8 h-8 bg-amber-50 text-amber-600 border border-amber-100 rounded-lg flex items-center justify-center">
              <ListOrdered className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">สถานะงานซ่อมที่กำหนด</h4>
              <span className="text-[10px] text-slate-400 font-sans font-medium">
                แท็บ: {config?.tabs?.statusTab || "รายการสถานะ"}
              </span>
            </div>
          </div>
          <div className="overflow-y-auto max-h-72 space-y-2 pr-1 scrollbar-thin">
            {!config || config.statuses.length === 0 ? (
              <span className="text-xs text-slate-400 font-sans block text-center py-4">ไม่มีสถานะระบุในชีต</span>
            ) : (
              config.statuses.map((s, idx) => (
                <div key={idx} className="flex justify-between items-center bg-slate-50 border border-slate-100 p-2.5 rounded-2xl text-xs font-sans font-semibold">
                  <span className="text-slate-800">{s}</span>
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Security Alert / Role constraint summary */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl flex items-start gap-4 border border-slate-800 shadow-sm">
        <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 flex items-center justify-center flex-shrink-0 mt-0.5">
          <ShieldAlert className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-100 font-sans uppercase tracking-wider">
            สรุปขอบเขตสิทธิ์ความปลอดภัยในระบบ (Role Boundaries)
          </h4>
          <ul className="text-xs text-slate-300 mt-2 font-sans list-disc pl-4 space-y-2">
            <li>
              <strong>ผู้แจ้งซ่อม (Reporter):</strong> ส่งใบแจ้งงานได้ใหม่ได้อย่างเดียว มองเห็นรายการอัปเดตและประวัติได้ แต่แก้ไข/อัปเดตข้อมูลสถานะ/หมายเหตุไม่ได้
            </li>
            <li>
              <strong>ช่างซ่อม (Technician):</strong> มองเห็นใบงาน สามารถปรับปรุงสถานะ (รับแจ้งแล้ว &rarr; กำลังดำเนินการ &rarr; รออะไหล่ &rarr; เสร็จสิ้น) บันทึกช่างผู้รับผิดชอบ และกรอกผลการซ่อมแซมได้
            </li>
            <li>
              <strong>ผู้ดูแลระบบ (Admin):</strong> มีสิทธิ์ระดับสูงสุด สามารถมองเห็นและบริหารจัดการได้ทุกส่วน รวมถึงแก้ไขแท็บการตั้งค่า
            </li>
          </ul>
        </div>
      </div>

    </div>
  );
}
