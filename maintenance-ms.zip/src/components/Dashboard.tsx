import React, { useMemo } from "react";
import { RepairRecord } from "@/src/types";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import {
  Wrench,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Search,
  ClipboardList,
} from "lucide-react";

interface DashboardProps {
  records: RepairRecord[];
  onSelectJob: (jobNo: string) => void;
  userRole: string;
}

export default function Dashboard({ records, onSelectJob, userRole }: DashboardProps) {
  const [searchTerm, setSearchTerm] = React.useState("");

  // Filter records based on search
  const filteredRecent = useMemo(() => {
    return records
      .filter(
        (r) =>
          r.jobNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.machineModel.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.spec.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.details.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .slice(0, 5);
  }, [records, searchTerm]);

  // Calculations for stats
  const stats = useMemo(() => {
    const total = records.length;
    const pending = records.filter((r) => r.status === "รับแจ้งแล้ว").length;
    const inProgress = records.filter(
      (r) => r.status === "กำลังดำเนินการ" || r.status === "รออะไหล่"
    ).length;
    const completed = records.filter(
      (r) => r.status === "เสร็จสิ้น" || r.status === "ยกเลิก"
    ).length;

    return { total, pending, inProgress, completed };
  }, [records]);

  // Recharts trend data
  const chartData = useMemo(() => {
    // Group records by day of the last 7 days
    const days = ["อาทิตย์", "จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์"];
    const results = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const dateString = d.toLocaleDateString("th-TH", {
        day: "numeric",
        month: "short",
      });
      const dayOfWeek = days[d.getDay()];

      // Count records on this day
      const count = records.filter((r) => {
        if (!r.reportedAt) return false;
        // Parsing "20/7/2569" or standard locale strings
        // We can do a simpler match using just date comparison or substring
        const recordDate = r.reportedAt.split(" ")[0]; // e.g. "20/7/2569"
        // Convert JS date to approximate Thai format string for simple comparison
        const jsThDate = d.toLocaleDateString("th-TH").split(" ")[0];
        return recordDate === jsThDate;
      }).length;

      return {
        name: dateString,
        day: dayOfWeek,
        ปริมาณ: count,
      };
    });

    return results;
  }, [records]);

  // Urgent / High priority issues (e.g. pending status for over a day, or special types)
  const urgentIssues = useMemo(() => {
    return records
      .filter((r) => r.status === "รับแจ้งแล้ว" || r.status === "รออะไหล่")
      .slice(0, 3);
  }, [records]);

  return (
    <div className="space-y-6">
      {/* KPI Bento Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Requests */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-blue-50 text-blue-600">
              <ClipboardList className="w-5 h-5" />
            </div>
            <span className="text-xs text-slate-400 font-medium font-sans">All Tasks</span>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-900 font-sans leading-none">
              {stats.total.toLocaleString()}
            </div>
            <div className="text-xs font-bold text-slate-500 mt-2 font-sans uppercase tracking-wider">
              รายการทั้งหมด
            </div>
          </div>
        </div>

        {/* Pending Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-amber-50 text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
            <span className="text-xs text-slate-400 font-medium font-sans">Received</span>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-900 font-sans leading-none">
              {stats.pending.toLocaleString()}
            </div>
            <div className="text-xs font-bold text-amber-600 mt-2 font-sans uppercase tracking-wider">
              รับแจ้งแล้ว
            </div>
          </div>
        </div>

        {/* In Progress Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-blue-50 text-blue-600">
              <Wrench className="w-5 h-5" />
            </div>
            <span className="text-xs text-slate-400 font-medium font-sans">In Progress</span>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-900 font-sans leading-none">
              {stats.inProgress.toLocaleString()}
            </div>
            <div className="text-xs font-bold text-blue-600 mt-2 font-sans uppercase tracking-wider">
              กำลังดำเนินการ
            </div>
          </div>
        </div>

        {/* Completed Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <span className="text-xs text-slate-400 font-medium font-sans">Completed</span>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-900 font-sans leading-none">
              {stats.completed.toLocaleString()}
            </div>
            <div className="text-xs font-bold text-emerald-600 mt-2 font-sans uppercase tracking-wider">
              เสร็จสิ้น / ยกเลิก
            </div>
          </div>
        </div>
      </div>

      {/* Charts and Urgent Tasks Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Area Chart */}
        <div className="lg:col-span-2 bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span className="w-1.5 h-4 bg-blue-500 rounded-full inline-block"></span>
                ปริมาณงานซ่อม 7 วันที่ผ่านมา
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">สถิติปริมาณการแจ้งซ่อมรายวันในสัปดาห์นี้</p>
            </div>
          </div>
          <div className="flex-1 w-full min-h-[250px] relative">
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderRadius: "12px",
                    color: "#fff",
                    border: "none",
                  }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold" }}
                />
                <Area
                  type="monotone"
                  dataKey="ปริมาณ"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorVolume)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Urgent Tasks */}
        <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span className="w-1.5 h-4 bg-amber-500 rounded-full inline-block"></span>
                งานรอช่างตรวจสอบ
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">รายการแจ้งเข้ามาใหม่ที่รอดำเนินการ</p>
            </div>
          </div>
          <div className="flex-1 flex flex-col gap-4 overflow-y-auto max-h-[250px] pr-1">
            {urgentIssues.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 py-8">
                <CheckCircle2 className="w-10 h-10 mb-2 text-emerald-500 bg-emerald-50 p-2 rounded-full" />
                <span className="text-xs font-bold font-sans text-slate-500">ไม่มีงานค้างเลย ยอดเยี่ยมมาก!</span>
              </div>
            ) : (
              urgentIssues.map((issue) => (
                <div
                  key={issue.jobNo}
                  onClick={() => onSelectJob(issue.jobNo)}
                  className="flex gap-3 items-start border-b border-slate-100 pb-3 last:border-0 cursor-pointer hover:bg-slate-50 p-2 rounded-2xl transition-all"
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${
                    issue.status === "รออะไหล่" ? "bg-amber-50 text-amber-600" : "bg-yellow-50 text-yellow-600"
                  }`}>
                    {issue.status === "รออะไหล่" ? (
                      <AlertTriangle className="w-4 h-4" />
                    ) : (
                      <Clock className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-sm text-slate-800 truncate">
                        {issue.machineModel || "ไม่ระบุรุ่น"}
                      </span>
                      <span className="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded font-bold font-sans border border-blue-100">
                        {issue.jobNo}
                      </span>
                    </div>
                    <div className="font-sans text-xs text-slate-500 truncate mt-0.5">
                      {issue.spec || "ไม่ระบุสเปค"}
                    </div>
                    <div className="font-sans text-[10px] text-slate-400 mt-1">
                      แจ้งเมื่อ: {issue.reportedAt}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Requests Table */}
      <div className="bg-white border border-slate-200/60 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-blue-500 rounded-full inline-block"></span>
              รายการแจ้งซ่อมล่าสุด
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 font-sans">อัปเดตและค้นหาข้อมูลสถานะได้แบบเรียลไทม์</p>
          </div>
          {/* Quick Search */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="ค้นหาเลขที่, รุ่นเครื่องจักร..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-xs"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  เลขที่งาน
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  รุ่นเครื่อง / สเปคงาน
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500">
                  วันเวลาแจ้ง
                </th>
                <th className="py-3 px-6 font-bold text-xs uppercase tracking-wider text-slate-500 text-center">
                  สถานะ
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecent.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-400 font-sans">
                    ไม่พบรายการข้อมูล
                  </td>
                </tr>
              ) : (
                filteredRecent.map((record) => (
                  <tr
                    key={record.jobNo}
                    onClick={() => onSelectJob(record.jobNo)}
                    className="hover:bg-slate-50/30 cursor-pointer transition-colors"
                  >
                    <td className="py-4 px-6">
                      <span className="font-bold text-blue-600 font-sans">{record.jobNo}</span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-bold text-slate-800 leading-tight">
                        {record.machineModel || "ไม่ระบุ"}
                      </p>
                      <p className="text-xs text-slate-500 truncate max-w-xs font-sans mt-0.5">
                        {record.spec || "ไม่มีสเปค"} - {record.details}
                      </p>
                    </td>
                    <td className="py-4 px-6 text-xs text-slate-500 font-sans">
                      {record.reportedAt}
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span
                        className={`inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-bold font-sans ${
                          record.status === "รับแจ้งแล้ว"
                            ? "bg-amber-100 text-amber-800 border border-amber-200"
                            : record.status === "กำลังดำเนินการ"
                            ? "bg-blue-100 text-blue-800 border border-blue-200"
                            : record.status === "รออะไหล่"
                            ? "bg-amber-100 text-amber-800 border border-amber-200"
                            : record.status === "เสร็จสิ้น"
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                            : "bg-rose-100 text-rose-800 border border-rose-200"
                        }`}
                      >
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
