import React, { useMemo } from "react";
import { RepairRecord, SheetUser } from "@/src/types";
import { Wrench, CheckCircle2, Clock, Shield, User, Trophy } from "lucide-react";

interface TechniciansProps {
  records: RepairRecord[];
  users: SheetUser[];
}

export default function Technicians({ records, users }: TechniciansProps) {
  // Filter registered technicians from spreadsheet "ผู้ใช้งาน"
  const technicians = useMemo(() => {
    return users.filter((u) => u.role === "ช่างซ่อม");
  }, [users]);

  // Compute workload and performance statistics per technician
  const technicianStats = useMemo(() => {
    return technicians.map((tech) => {
      // Find all jobs assigned to this technician (matching their ID or name)
      const assignedJobs = records.filter(
        (r) =>
          r.technicianId === tech.id ||
          r.technicianId.toLowerCase() === tech.id.toLowerCase()
      );

      const completed = assignedJobs.filter((r) => r.status === "เสร็จสิ้น").length;
      const active = assignedJobs.filter(
        (r) => r.status === "กำลังดำเนินการ" || r.status === "รออะไหล่"
      ).length;

      return {
        ...tech,
        totalJobs: assignedJobs.length,
        completed,
        active,
      };
    });
  }, [technicians, records]);

  // Find the technician with the most completed jobs
  const topTechnician = useMemo(() => {
    if (technicianStats.length === 0) return null;
    return [...technicianStats].sort((a, b) => b.completed - a.completed)[0];
  }, [technicianStats]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/60 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 font-sans">
            <span className="w-1.5 h-5 bg-blue-500 rounded-full inline-block"></span>
            ทีมช่างเทคนิคผู้ปฏิบัติการ
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            ภาพรวมการกระจายภาระงาน ประสิทธิภาพการปิดงาน และสถานะกำลังปฏิบัติงานของทีมช่างในระบบ
          </p>
        </div>
      </div>

      {/* Top Performer Card */}
      {topTechnician && topTechnician.completed > 0 && (
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-blue-900 p-6 rounded-3xl text-white shadow-md flex flex-col sm:flex-row justify-between items-center gap-4 border border-slate-700/50">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-yellow-400">
              <Trophy className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] bg-blue-500/30 text-blue-300 border border-blue-500/20 font-bold tracking-wider px-2.5 py-0.5 rounded-full uppercase">
                ช่างผู้สร้างผลงานดีเด่น
              </span>
              <h3 className="text-lg font-bold mt-1 text-slate-100">{topTechnician.name}</h3>
              <p className="text-xs text-slate-300 font-sans">
                ดูแลซ่อมแซมเครื่องจักรเสร็จสิ้นไปแล้วกว่า {topTechnician.completed} งานในสัปดาห์นี้!
              </p>
            </div>
          </div>
          <div className="text-right sm:border-l sm:border-slate-700/50 sm:pl-6">
            <span className="text-xs text-slate-400">ปริมาณงานที่รับผิดชอบทั้งหมด</span>
            <div className="text-2xl font-extrabold font-sans text-slate-100 mt-1">{topTechnician.totalJobs} งาน</div>
          </div>
        </div>
      )}

      {/* Technicians Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {technicianStats.length === 0 ? (
          <div className="col-span-full bg-white p-12 text-center text-slate-400 font-sans border border-slate-200/60 rounded-3xl shadow-sm">
            <User className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            ยังไม่มีข้อมูลช่างเทคนิคที่ลงทะเบียนในระบบ
            <p className="text-xs text-slate-400 mt-1">
              * ลงทะเบียนช่างเพิ่มได้โดยตรงใน Google Sheet แท็บ &quot;ผู้ใช้งาน&quot;
            </p>
          </div>
        ) : (
          technicianStats.map((tech) => (
            <div
              key={tech.id}
              className="bg-white border border-slate-200/60 rounded-3xl shadow-sm p-6 flex flex-col justify-between hover:shadow-md transition-all duration-300 hover:-translate-y-0.5"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 text-slate-600 flex items-center justify-center">
                    <Wrench className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">{tech.name}</h4>
                    <span className="text-[10px] text-slate-400 font-sans font-medium">
                      รหัสพนักงาน: {tech.id}
                    </span>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 bg-slate-50 border border-slate-200/60 text-slate-600 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase font-sans">
                  <Shield className="w-3 h-3 text-blue-500" />
                  ช่างซ่อม
                </span>
              </div>

              {/* Stats Counters */}
              <div className="grid grid-cols-3 gap-4 border-t border-slate-100 pt-4 text-center font-sans">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">
                    งานทั้งหมด
                  </span>
                  <p className="text-lg font-extrabold text-slate-800 mt-0.5">{tech.totalJobs}</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider flex items-center justify-center gap-0.5">
                    <Clock className="w-3 h-3 text-amber-500" /> กำลังซ่อม
                  </span>
                  <p className="text-lg font-extrabold text-amber-600 mt-0.5">{tech.active}</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider flex items-center justify-center gap-0.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" /> เสร็จสิ้น
                  </span>
                  <p className="text-lg font-extrabold text-emerald-600 mt-0.5">{tech.completed}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
