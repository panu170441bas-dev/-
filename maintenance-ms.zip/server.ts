import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Set up JSON body parser with a large limit to support base64 image uploads
app.use(express.json({ limit: "20mb" }));

// Google Spreadsheet ID and Google Drive Folder ID
const SPREADSHEET_ID = "1zLZo2Igpqk59skiAyFTBPhgbq4J1Gm47zA4Y0ru6-Dg";
const DRIVE_FOLDER_ID = "15nyU9E6v87PJHOflz7kTkwuM3QfuopUS";

// Helper: Get user profile from Google Access Token
async function getGoogleUserProfile(accessToken: string) {
  try {
    const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) {
      throw new Error(`Failed to fetch user info: ${res.statusText}`);
    }
    return await res.json();
  } catch (error) {
    console.error("Error fetching Google profile:", error);
    throw error;
  }
}

// Helper: Get sheet values
async function getSheetValues(accessToken: string, range: string) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${encodeURIComponent(range)}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    if (res.status === 404) {
      return null;
    }
    throw new Error(`Failed to fetch sheet values for ${range}: ${res.statusText}`);
  }
  const data = await res.json();
  return data.values || [];
}

// Helper: Create a sheet tab if it doesn't exist
async function ensureSheetTabExists(accessToken: string, title: string, headers: string[]) {
  try {
    // Check if the spreadsheet metadata contains this sheet
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!metaRes.ok) {
      throw new Error(`Failed to get spreadsheet metadata: ${metaRes.statusText}`);
    }
    const meta = await metaRes.json();
    const sheetExists = meta.sheets?.some((s: any) => s.properties?.title === title);

    if (!sheetExists) {
      console.log(`Sheet "${title}" not found. Creating it...`);
      const createRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              addSheet: {
                properties: {
                  title,
                },
              },
            },
          ],
        }),
      });

      if (!createRes.ok) {
        throw new Error(`Failed to create sheet tab ${title}: ${createRes.statusText}`);
      }

      // Add headers
      const headerRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${encodeURIComponent(title)}!A1:Z1?valueInputOption=USER_ENTERED`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          values: [headers],
        }),
      });

      if (!headerRes.ok) {
        console.error(`Failed to add headers to sheet tab ${title}`);
      } else {
        console.log(`Successfully created sheet "${title}" with headers.`);
      }
    }
  } catch (err) {
    console.error("Error ensuring sheet tab exists:", err);
  }
}

// Ensure the core "บันทึกงาน" sheet exists on start or when first API call hits
const JOB_SHEET_HEADERS = [
  "เลขที่งาน",
  "วันเวลาที่แจ้ง",
  "ID ผู้แจ้งซ่อม",
  "สถานที่/แผนก",
  "เลขเครื่อง",
  "รุ่นเครื่องจักร",
  "สเปคงาน/ประเภทปัญหา",
  "รายละเอียดปัญหา",
  "รูปถ่ายประกอบ",
  "สถานะงาน",
  "ID ผู้ซ่อม/ผู้ปฏิบัติงาน",
  "วันที่เสร็จสิ้น",
  "หมายเหตุ/ผลการซ่อม",
];

// API: Get App Config & Reference Data from Google Sheet
app.get("/api/maintenance/config", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];

  try {
    // Get user info first
    const googleUser = await getGoogleUserProfile(token);
    const userEmail = googleUser.email;
    const userName = googleUser.name;

    // Fetch sheet metadata to find correct tab names dynamically
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!metaRes.ok) {
      return res.status(metaRes.status).json({ error: "Failed to access Google Sheet. Please check spreadsheet sharing permissions." });
    }
    const meta = await metaRes.json();
    const sheets = meta.sheets || [];

    // Find tab titles dynamically
    const modelSpecTab = sheets.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("รุ่น") || title.toLowerCase().includes("model");
    })?.properties?.title || "รุ่น+สเปค";

    const statusTab = sheets.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("สถานะ") || title.toLowerCase().includes("status");
    })?.properties?.title || "รายการสถานะ";

    const userTab = sheets.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("ผู้ใช้") || title.toLowerCase().includes("user");
    })?.properties?.title || "ผู้ใช้งาน";

    const jobTab = sheets.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("บันทึก") || title.toLowerCase().includes("record") || title.toLowerCase().includes("job") || title.toLowerCase().includes("maintenance");
    })?.properties?.title || "บันทึกงาน";

    // Ensure job sheet exists
    await ensureSheetTabExists(token, jobTab, JOB_SHEET_HEADERS);

    // Ensure user sheet exists with correct headers
    const USER_SHEET_HEADERS = ["ID ผู้ใช้งาน", "รหัสผ่าน", "ชื่อ-สกุล", "สิทธิ์", "สถานะบัญชี"];
    await ensureSheetTabExists(token, userTab, USER_SHEET_HEADERS);

    // Fetch data in parallel
    const [modelSpecRows, statusRows, userRows] = await Promise.all([
      getSheetValues(token, `${modelSpecTab}!A1:B1000`).catch(() => []),
      getSheetValues(token, `${statusTab}!A1:A100`).catch(() => []),
      getSheetValues(token, `${userTab}!A1:E500`).catch(() => []),
    ]);

    // 1. Process Model + Spec (support merged cells!)
    const modelsAndSpecs: { model: string; spec: string }[] = [];
    let currentModel = "";
    modelSpecRows.forEach((row: string[], index: number) => {
      // Skip headers if the row contains typical keywords
      if (index === 0 && (row[0]?.includes("รุ่น") || row[0]?.toLowerCase().includes("model"))) {
        return;
      }
      const modelVal = row[0]?.trim();
      const specVal = row[1]?.trim();

      if (modelVal) {
        currentModel = modelVal;
      }

      if (specVal) {
        modelsAndSpecs.push({
          model: currentModel,
          spec: specVal,
        });
      }
    });

    // 2. Process Status List
    let statuses: string[] = [];
    statusRows.forEach((row: string[], index: number) => {
      if (index === 0 && (row[0]?.includes("สถานะ") || row[0]?.toLowerCase().includes("status"))) {
        return;
      }
      const statusVal = row[0]?.trim();
      if (statusVal) {
        statuses.push(statusVal);
      }
    });
    // Fallback if empty or failed to load
    if (statuses.length === 0) {
      statuses = ["รับแจ้งแล้ว", "กำลังดำเนินการ", "รออะไหล่", "เสร็จสิ้น", "ยกเลิก"];
    }

    // 3. Process Users and match current user (do not expose password field)
    const users: { id: string; name: string; role: string; status: string }[] = [];
    const customUserId = (req.headers["x-user-id"] || "").toString().trim();
    
    let matchedUserRole = "ผู้แจ้งซ่อม"; // Default role
    let matchedUserName = userName;
    let matchedUserStatus = "เปิดใช้งาน";

    userRows.forEach((row: string[], index: number) => {
      if (index === 0 && (row[0]?.includes("ID") || row[0]?.toLowerCase().includes("user"))) {
        return;
      }
      const userId = row[0]?.trim();
      // row[1] is Password - keep secure and do not return
      const nameVal = row[2]?.trim();
      const roleVal = row[3]?.trim();
      const statusVal = row[4]?.trim() || "เปิดใช้งาน";

      if (userId && nameVal && roleVal) {
        users.push({ id: userId, name: nameVal, role: roleVal, status: statusVal });

        // Match by customUserId if provided, otherwise fallback to matching by Google email
        const targetToMatch = customUserId ? customUserId.toLowerCase() : userEmail.toLowerCase();
        if (userId.toLowerCase() === targetToMatch) {
          matchedUserRole = roleVal;
          matchedUserName = nameVal;
          matchedUserStatus = statusVal;
        }
      }
    });

    res.json({
      profile: {
        email: userEmail,
        id: customUserId || userEmail,
        name: matchedUserName,
        googleName: userName,
        role: matchedUserRole, // "ผู้แจ้งซ่อม" | "ช่างซ่อม" | "ผู้ดูแลระบบ"
        status: matchedUserStatus,
      },
      modelsAndSpecs,
      statuses,
      users,
      tabs: {
        modelSpecTab,
        statusTab,
        userTab,
        jobTab,
      },
    });
  } catch (error: any) {
    console.error("Config fetch error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Verify Custom User Credentials (User ID + Password)
app.post("/api/maintenance/login", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];
  const { userId, password } = req.body;

  if (!userId || !password) {
    return res.status(400).json({ error: "กรุณากรอก ID ผู้ใช้งานและรหัสผ่าน" });
  }

  try {
    // Fetch user tab name
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const meta = await metaRes.json();
    const userTab = meta.sheets?.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("ผู้ใช้") || title.toLowerCase().includes("user");
    })?.properties?.title || "ผู้ใช้งาน";

    // Ensure user sheet exists
    const USER_SHEET_HEADERS = ["ID ผู้ใช้งาน", "รหัสผ่าน", "ชื่อ-สกุล", "สิทธิ์", "สถานะบัญชี"];
    await ensureSheetTabExists(token, userTab, USER_SHEET_HEADERS);

    const userRows = await getSheetValues(token, `${userTab}!A1:E500`);
    if (!userRows || userRows.length <= 1) {
      return res.status(404).json({ error: "ไม่พบข้อมูลผู้ใช้งานในระบบ Google Sheets" });
    }

    // Look for matching user
    let foundUser = null;
    for (let i = 1; i < userRows.length; i++) {
      const row = userRows[i];
      const uId = row[0]?.trim();
      const uPass = row[1]?.trim();
      const uName = row[2]?.trim();
      const uRole = row[3]?.trim();
      const uStatus = row[4]?.trim() || "เปิดใช้งาน";

      if (uId && uId.toLowerCase() === userId.trim().toLowerCase()) {
        foundUser = { id: uId, password: uPass, name: uName, role: uRole, status: uStatus };
        break;
      }
    }

    if (!foundUser) {
      return res.status(401).json({ error: "ไม่พบ ID ผู้ใช้งานนี้ในระบบ" });
    }

    if (foundUser.password !== password.trim()) {
      return res.status(401).json({ error: "รหัสผ่านไม่ถูกต้อง" });
    }

    if (foundUser.status !== "เปิดใช้งาน") {
      return res.status(403).json({ error: "บัญชีผู้ใช้งานนี้ถูกระงับการใช้งานชั่วคราว" });
    }

    // Success
    res.json({
      success: true,
      user: {
        id: foundUser.id,
        name: foundUser.name,
        role: foundUser.role,
        status: foundUser.status
      }
    });
  } catch (error: any) {
    console.error("Login verification error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Get All Repair Records
app.get("/api/maintenance/records", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];

  try {
    // Find correct job tab name
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const meta = await metaRes.json();
    const jobTab = meta.sheets?.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("บันทึก") || title.toLowerCase().includes("record") || title.toLowerCase().includes("job") || title.toLowerCase().includes("maintenance");
    })?.properties?.title || "บันทึกงาน";

    const rows = await getSheetValues(token, `${jobTab}!A1:M5000`);
    if (!rows || rows.length <= 1) {
      return res.json([]);
    }

    // Skip header row
    const records = rows.slice(1).map((row: string[], index: number) => {
      return {
        rowNumber: index + 2, // 1-based index including headers
        jobNo: row[0] || "",
        reportedAt: row[1] || "",
        reporterId: row[2] || "",
        location: row[3] || "",
        machineNo: row[4] || "",
        machineModel: row[5] || "",
        spec: row[6] || "",
        details: row[7] || "",
        photoUrl: row[8] || "",
        status: row[9] || "รับแจ้งแล้ว",
        technicianId: row[10] || "",
        completedAt: row[11] || "",
        notes: row[12] || "",
      };
    }).filter((r: any) => r.jobNo); // Filter out empty lines

    res.json(records);
  } catch (error: any) {
    console.error("Records fetch error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Create a New Repair Record
app.post("/api/maintenance/records", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];

  try {
    const googleUser = await getGoogleUserProfile(token);
    const customUserId = (req.headers["x-user-id"] || "").toString().trim();
    const reporterId = customUserId || googleUser.email;

    // Get current Job tab name
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const meta = await metaRes.json();
    const jobTab = meta.sheets?.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("บันทึก") || title.toLowerCase().includes("record") || title.toLowerCase().includes("job") || title.toLowerCase().includes("maintenance");
    })?.properties?.title || "บันทึกงาน";

    // 1. Fetch current rows to find next Job No
    const rows = await getSheetValues(token, `${jobTab}!A1:A5000`);
    let nextJobNum = 1;
    if (rows && rows.length > 1) {
      // Find the maximum job number
      const numbers = rows.slice(1).map((row: string[]) => {
        const val = row[0] || "";
        const match = val.match(/REQ-(\d+)/i);
        return match ? parseInt(match[1], 10) : 0;
      });
      const maxNum = Math.max(...numbers, 0);
      nextJobNum = maxNum + 1;
    }
    const jobNo = `REQ-${String(nextJobNum).padStart(4, "0")}`;

    // 2. Extract and format input data
    const {
      location,
      machineNo,
      machineModel,
      spec,
      details,
      photoUrl,
    } = req.body;

    const reportedAt = new Date().toLocaleString("th-TH", { timeZone: "Asia/Bangkok" });

    // Format machineNo to protect leading zeros by prefixing with ' in Google Sheet
    const formattedMachineNo = `'${machineNo}`;

    // New Row data matching JOB_SHEET_HEADERS
    const newRow = [
      jobNo,                  // เลขที่งาน (A)
      reportedAt,             // วันเวลาที่แจ้ง (B)
      reporterId,             // ID ผู้แจ้งซ่อม (C)
      location || "",         // สถานที่/แผนก (D)
      formattedMachineNo,     // เลขเครื่อง (E)
      machineModel || "",     // รุ่นเครื่องจักร (F)
      spec || "",             // สเปคงาน/ประเภทปัญหา (G)
      details || "",          // รายละเอียดปัญหา (H)
      photoUrl || "",         // รูปถ่ายประกอบ (I)
      "รับแจ้งแล้ว",           // สถานะงาน (J)
      "",                     // ID ผู้ซ่อม/ผู้ปฏิบัติงาน (K)
      "",                     // วันที่เสร็จสิ้น (L)
      "",                     // หมายเหตุ/ผลการซ่อม (M)
    ];

    // 3. Append to spreadsheet
    const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${encodeURIComponent(jobTab)}!A1:M1:append?valueInputOption=USER_ENTERED`;
    const appendRes = await fetch(appendUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        values: [newRow],
      }),
    });

    if (!appendRes.ok) {
      const errText = await appendRes.text();
      throw new Error(`Failed to append row to Google Sheet: ${errText}`);
    }

    res.json({ success: true, jobNo, reportedAt, reporterId });
  } catch (error: any) {
    console.error("Record creation error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Update an Existing Repair Record (Technician/Admin)
app.put("/api/maintenance/records/:jobNo", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];
  const { jobNo } = req.params;

  try {
    // 1. Fetch job tab title and existing rows to locate the row index
    const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const meta = await metaRes.json();
    const jobTab = meta.sheets?.find((s: any) => {
      const title = s.properties?.title || "";
      return title.includes("บันทึก") || title.toLowerCase().includes("record") || title.toLowerCase().includes("job") || title.toLowerCase().includes("maintenance");
    })?.properties?.title || "บันทึกงาน";

    const rows = await getSheetValues(token, `${jobTab}!A1:M5000`);
    if (!rows) {
      return res.status(404).json({ error: "No records found in spreadsheet" });
    }

    // Find row index (1-based index for sheets, headers is row 1, index + 1)
    const rowIndex = rows.findIndex((row: string[]) => row[0]?.trim() === jobNo) + 1;
    if (rowIndex <= 1) {
      return res.status(404).json({ error: `Record with Job No ${jobNo} not found` });
    }

    const currentRecord = rows[rowIndex - 1];

    // Extract fields to update from body
    const {
      status,          // J (10th column)
      technicianId,    // K (11th column)
      completedAt,     // L (12th column)
      notes,           // M (13th column)
      location,        // D (4th column)
      machineNo,       // E (5th column)
      machineModel,    // F (6th column)
      spec,            // G (7th column)
      details,         // H (8th column)
    } = req.body;

    // Prepare updated row values
    const updatedRow = [...currentRecord];

    // Update allowable fields
    if (location !== undefined) updatedRow[3] = location;
    if (machineNo !== undefined) updatedRow[4] = machineNo.startsWith("'") ? machineNo : `'${machineNo}`;
    if (machineModel !== undefined) updatedRow[5] = machineModel;
    if (spec !== undefined) updatedRow[6] = spec;
    if (details !== undefined) updatedRow[7] = details;
    if (status !== undefined) updatedRow[9] = status;
    if (technicianId !== undefined) updatedRow[10] = technicianId;
    if (completedAt !== undefined) updatedRow[11] = completedAt;
    if (notes !== undefined) updatedRow[12] = notes;

    // Create a clean array of exactly 13 elements, mapping undefined/null to empty string
    const finalRow = Array.from({ length: 13 }, (_, i) => {
      const val = updatedRow[i];
      return (val === undefined || val === null) ? "" : val;
    });

    // Update row in spreadsheet
    const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${encodeURIComponent(jobTab)}!A${rowIndex}:M${rowIndex}?valueInputOption=USER_ENTERED`;
    const updateRes = await fetch(updateUrl, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        values: [finalRow],
      }),
    });

    if (!updateRes.ok) {
      const errText = await updateRes.text();
      throw new Error(`Failed to update row in Google Sheet: ${errText}`);
    }

    res.json({ success: true, jobNo, updatedValues: finalRow });
  } catch (error: any) {
    console.error("Record update error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Upload base64 image to Google Drive
app.post("/api/maintenance/upload", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  const token = authHeader.split(" ")[1];

  try {
    const { base64Data, fileName } = req.body;
    if (!base64Data) {
      return res.status(400).json({ error: "Missing base64Data" });
    }

    // Extract raw base64 data and mime type
    const match = base64Data.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!match) {
      return res.status(400).json({ error: "Invalid data URI schema" });
    }
    const mimeType = match[1];
    const base64Raw = match[2];
    const buffer = Buffer.from(base64Raw, "base64");

    // Perform Google Drive Multipart upload
    const boundary = "boundary_marker_reliant_maintenance";
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const metadata = {
      name: fileName || `maintenance_photo_${Date.now()}.jpg`,
      mimeType: mimeType,
      parents: [DRIVE_FOLDER_ID],
    };

    // Construct request body with metadata and binary data
    const metadataPart = JSON.stringify(metadata);
    
    // We concatenate buffer in Node
    const multipartBody = Buffer.concat([
      Buffer.from(delimiter),
      Buffer.from("Content-Type: application/json; charset=UTF-8\r\n\r\n"),
      Buffer.from(metadataPart),
      Buffer.from(delimiter),
      Buffer.from(`Content-Type: ${mimeType}\r\nContent-Transfer-Encoding: base64\r\n\r\n`),
      Buffer.from(base64Raw),
      Buffer.from(closeDelimiter),
    ]);

    const uploadUrl = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";
    const uploadRes = await fetch(uploadUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": `multipart/related; boundary=${boundary}`,
        "Content-Length": String(multipartBody.length),
      },
      body: multipartBody,
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      throw new Error(`Google Drive upload failed: ${errText}`);
    }

    const fileInfo = await uploadRes.json();
    const fileId = fileInfo.id;

    // Set permission to anyone with link can view (so it can render on the front-end)
    try {
      const permUrl = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions`;
      await fetch(permUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          role: "reader",
          type: "anyone",
        }),
      });
    } catch (permErr) {
      console.warn("Failed to set file permissions to public, proxy fallback will still work:", permErr);
    }

    res.json({
      success: true,
      fileId,
      name: metadata.name,
      // Provide direct lh3 URL as well as a proxy-based URL
      photoUrl: `/api/drive-image/${fileId}`,
    });
  } catch (error: any) {
    console.error("Upload error:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API: Proxy image download from Google Drive (works even for private images if authorized)
app.get("/api/drive-image/:fileId", async (req, res) => {
  const authHeader = req.headers.authorization;
  const queryToken = req.query.token as string;
  
  // Accept token in header or query param (for <img> src tags)
  const token = authHeader?.startsWith("Bearer ") ? authHeader.split(" ")[1] : queryToken;
  
  if (!token) {
    return res.status(401).send("Unauthorized: Missing Access Token");
  }

  const { fileId } = req.params;

  try {
    const fetchUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const driveRes = await fetch(fetchUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!driveRes.ok) {
      return res.status(driveRes.status).send("Failed to retrieve image from Google Drive");
    }

    const contentType = driveRes.headers.get("Content-Type") || "image/jpeg";
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "private, max-age=86400"); // Cache image client-side

    const arrayBuffer = await driveRes.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (error) {
    console.error("Error proxying Drive image:", error);
    res.status(500).send("Internal server error");
  }
});

// Vite middleware integration / static server setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Reliant Maintenance] Server is running on http://localhost:${PORT}`);
  });
}

startServer();
